<?php
class Bmipasien_model extends CI_Model {
    public $id, $tanggal, $pasien, $bmi;
    
}
?>